//Author: Monynich Kiem
//Date: Feb. 25, 2020
//Section: 002
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include"trees.h"
#include<bits/stdc++.h>
using namespace std;

int main(int argc, char* argv[])
{
	if (argc != 2)
        {
                cout << "Warning: Need 1 command line argument." << endl;
                cout << "Usage: " << argv[0] << " inputfile_name" << endl;
                return 0;
        }//if the number of arguments does not match, the program will fail gently 

	int n; //standard input, and then the 3 integer components
        n = atoi(argv[1]); //n is the number of data points/leaves in the tree
        struct Leaf *Tree1 = NULL; //making sure the trees are empty
        struct Leaf *Tree2 = NULL; //making sure the trees are empty
		
	point value;
	cin >> value.x >> value.y >> value.z;
	value.key = value.x; //this is going to be the root of the tree
	Tree1 = newLeaf(value); //this sets the number of nodes/leaves the tree will have
	for (int a = 1; a < n; a+=1)
	{
		cin >> value.x >> value.y >> value.z;
		insert(Tree1, value, 1);
	}//for loop to insert the number of arguments until it reaches the number of nodes from standard input
	cout << "Symmetric:" << endl;	
	symmetricOrder(Tree1);//orders the trees and outputs the point in this format (x,y,z)
	value.key = value.y;//this resets the new root of tree 2 to be sorted on the y value
	
	Tree2 = newLeaf(value);//this populates tree 2 with the number of nodes based on the root
	preOrder(Tree1, Tree2);//this traverses T1 in preorder, placing each node in an initially empty binary tree T2 sorted on the Y value. It resolves ties by going to the left.
	cout << "Postorder" << endl;
	postOrder(Tree2);//this traverses T2 in postorder, printing each point on a separate line in the same format as before
	
	point probe;
	cin >> probe.y;
	minDiff(Tree2, probe.y);//this reads one more integer from standard input: the probe p, a Y value. It searches for p in T2, printing the last point it encounters as it descends through T2, which might have p itself as its Y value, or its Y value might just be close to p.
	return 0;
}//end of main
