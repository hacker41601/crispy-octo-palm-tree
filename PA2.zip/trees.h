#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<bits/stdc++.h>
using namespace std;

struct point
{
        int  x,y,z, key;
};//end of point struct

struct Leaf
{
        int data;
	point val;
        struct Leaf *left, *right;
};//end of Leaf struct

struct Leaf *newLeaf(point data)
{
        struct Leaf *tempLeaf = (struct Leaf*)malloc(sizeof(struct Leaf));
        tempLeaf->val = data;
        tempLeaf->left = tempLeaf->right = NULL;
        return tempLeaf;
}//end of newLeaf function, this function determines how many leaves will be on the binary tree based on user input

struct Leaf* insert(struct Leaf* leaf, point variable, int data)
{
	if (leaf == NULL)
	{
		return newLeaf(variable);
	}
	if (data < leaf->data)
	{
		leaf->left = insert(leaf->left, variable, data);
	}
	else if (data > leaf->data)
	{
		leaf->right = insert(leaf->right, variable, data);
	}
return leaf;
}//end of insert function, this function inserts data into the trees

struct Leaf* search(struct Leaf* leaf, int key)
{
        if (leaf == NULL)
        {
                return NULL;
        }
        else if (leaf->data == key)
        {
                return leaf;
        }
        else if (key < leaf->data)
        {
                return search(leaf->left, key);
        }
        else
        {
                return search(leaf->right, key);
      	}
}//end of search function, this function searches for the data using recursion by moving on down the tree to the next leaf based on the value of that leaf in comparison to the data

void minimum(struct Leaf *leaf, int key, int&min, int&min_diff)
{
	if (leaf == NULL)
		return;
	if (leaf->data == key)
	{
		min_diff = key;
		return;
	}
	if (min > abs(leaf->data - key))
	{
		min = abs(leaf->data - key);
		min_diff = leaf->data;
	}
	if (key < leaf->data)
	{
		minimum(leaf->left, key, min, min_diff);
	}
	else
	{
		minimum(leaf->right, key, min, min_diff); 
	}
}//end of minimum function that finds the minimum differece of a binary tree based on going left or right to the nearest number to the key

void minDiff(struct Leaf *leaf, int key)
{
	int min = INT_MAX, min_diff = -1;
	minimum(leaf, leaf->val.y, min, min_diff);
	cout << "(" << leaf->val.x << ", ";
        cout << leaf->val.y << ", ";
        cout << leaf->val.z << ")";
        cout << endl;
}//this outputs the node closest to the probe by calling minimum 

void postOrder(struct Leaf* leaf)
{
        if (leaf == NULL)
        {
                return;
        }

        postOrder(leaf->left);
        postOrder(leaf->right);
	cout << "(" << leaf->val.x << ", ";
        cout << leaf->val.y << ", ";
        cout << leaf->val.z << ")";
        cout << endl;
}//end of postOrder function that traverses the tree in postOrder form

void symmetricOrder (struct Leaf* leaf)
{
        if (leaf == NULL)
        {
                return;
        }
        symmetricOrder(leaf->left);
	cout << "(" << leaf->val.x << ", ";
	cout << leaf->val.y << ", ";
	cout << leaf->val.z << ")";
	cout << endl;
	symmetricOrder(leaf->right);
}//end of symmetricOrder function that traverses the tree in symmetricOrder form (in-order form) and prints out the tree in the format (x,y,z)

void preOrder(struct Leaf* T1, struct Leaf* T2)
{
        if (T1 == NULL)
        {
                return;
        }
	insert(T2, T1->val, T1->val.y); 
	preOrder(T1->left, T2);
        preOrder(T1->right, T2);
}//end of preOrder function that traverses the T1 in preOrder form and inserts each node in an initially empty T2 sorted on the y

