//Author: Monynich Kiem
//Section: CS315-002
//Date: 04/21/2020
//Program: 5, Genealogy
//Purpose: The purpose of this program is to demonstrate the use of a bipartite graph by creating a graph of genealogy among people, family, children, and their relations.

#include <iostream>
#include <string>
#include <sstream>
#include <string.h>
#include <vector>

using namespace std;

const int peopleEdge = 2; //no more than 2 edges
const int famEdge = 12; //no more than 12 edges per family
const int maxFam = 99; //the max number of families is 99

struct Edge 
{
	int source, destination;
}; //end of Edge struct

struct personVertex
{
	int id;
	Edge Edges[2];
};//end of personVertex struct

struct famVertex 
{
	int id;
	Edge Edges[12];
};//end of famVertex struct

Edge addEdge(int src, int dest)
{
	Edge newEdge;
	newEdge.source = src;
	newEdge.destination = dest;
	return newEdge;
}//function to add edges 

personVertex person(int person, int parent, int marriage)
{
	personVertex currInd;
	currInd.id = person;

	if (parent != 0)
	{
		currInd.Edges[0] = addEdge(person, parent);
	}

	if (marriage != 0)
	{
		currInd.Edges[1] = addEdge(person, marriage);
	}

	cout << "Person " << person << " has parents " << parent << " and is married in family " << marriage << "." << endl;
	return currInd;
}//end of person() function that identifies the person's number and adds the edges accordingly

famVertex family(int familia, int husband, int wife, vector<int>children)
{
	famVertex fam;
	fam.id = familia;

	if(husband != 0)
	{
		fam.Edges[0] = addEdge(familia, husband);
	}

	if(wife != 0)
	{
		fam.Edges[1] = addEdge(familia, wife);
	}

	for (size_t i = 0; i < children.size(); i+=1)
	{
		fam.Edges[i+2] = addEdge(familia, children[i]);
	}

	cout << "Family " << familia << " has husband " << husband << ", wife " << wife << ", and children";
	
	for (size_t j = 0; j < children.size(); j+=1)
	{
		cout << " " << children[j];
	}
	
	cout << "." << endl;

	return fam;
}//end of family() function that identifies family numbers and adds edges accordingly

int search(famVertex fam[], int key)
{
	int index = -1;
	
	for (int i = 0; i < maxFam; i+=1)
	{
		if (fam[i].id == key)
		{
			index = i;
		}
	}

	return index;
}//end of search() function that looks within families for a specific person

void BFS(int source, int numVertex, famVertex fam[], personVertex curr[])
{
	bool *visited = new bool[numVertex];

	for (int i = 0; i < numVertex; i +=1)
	{
		visited[i] = false;
	}

	vector<int> queue;
	visited[source] = true;
	queue.push_back(source);

	while (!queue.empty())
	{
		source = queue.back();
		cout << source << " ";
		queue.pop_back();

		for (auto i = queue.begin(); i != queue.end(); i +=1)
		{
			if (!visited[*i])
			{
				visited[*i] = true;
				queue.push_back(*i);
			}
		}
	}
}//end of BFS function to traverse the graph and is used for verify(). The reference is in the README file

void relate(int person1, int person2, famVertex fam[], int numFam, personVertex curr[], int numPerson)
{
	int numVertex = numFam + numPerson;
	BFS(person1, numVertex, fam, curr);
}//relate function that looks for the shortest patch and prints it out 

void verify(famVertex fam[], int famNum, personVertex curr[], int numPeople)
{
	bool steady = true;

	for (int i = 0; i < numPeople; i +=1)
	{
		for (int j = 0; j < peopleEdge; j +=1)
		{
			int relationship = curr[i].Edges[j].destination;

			if (relationship != 0)
			{
				int famInd = search(fam, relationship);

				if (famInd == -1)
				{
					cout << "Person " << i << " doesnt point to ";
					if (j ==0)
					{
						cout << "parent family " << relationship << "." << endl;
					}
					else
					{
						cout << "marriage family " << relationship << "." << endl;
					}
					steady = false;
				}

				else 
				{
					bool backPoint = false;
					
					for (int k = 0; k < famEdge; k+=1)
					{
						if (fam[famInd].Edges[k].destination == curr[i].id)
						{
							backPoint = true;
						}
						
					}

					if (backPoint == false)
					{
						cout << "Person " << i << " poimts to ";

						if (j == 0)
						{
							cout << "parent family " << relationship << "but there is no back-pointer." << endl;
						}
						else
						{
							cout << "marriage family " << relationship << " but there is no back-pointer." << endl;
						}
						
						steady = false;
					}
				}
			}
		}
	}

	if (steady == true)
	{
		cout << "The data is consistent.\n";	
	}
}//end of verify() function that determines whether or not the data input makes sense

int main()
{
	famVertex familia[99];
	personVertex persons[99];

	int numFam = 0;
	int numPerson = 0;

	for (int i = 0; i < maxFam; i+=1)
	{
		familia[i].id = 0;

		for (int j = 0; j < famEdge; j +=1)
		{
			familia[i].Edges[j].source = 0;
			familia[i].Edges[j].destination = 0;
		}	

		persons[i].id = 0;

		for (int j = 0; j < peopleEdge; j +=1)
		{
			persons[i].Edges[j].source = 0;
			persons[i].Edges[j].destination = 0;
		}
	}

	string cmd, line, word;

	while (getline(cin, line))
	{
		vector<string>tokens;
		stringstream ss(line);

		while (getline(ss,word, ' '))
		{
			tokens.push_back(word);
		}

		cmd = tokens[0];

		if (cmd == "Person")
		{
			int currPerson = stoi(tokens[1]);
			int parent = stoi(tokens[3]);
			int marriage = stoi(tokens[5]);

			int parentInd = search(familia, parent);

			if (parentInd == -1)
			{
				famVertex fam;
				fam.id = parent;
				familia[numFam] = fam;
				numFam++;
			}

			int marrInd = search(familia, marriage);

			if(marrInd == -1)
			{
				famVertex fam;
				fam.id = marriage;
				familia[numFam] = fam;
				numFam++;
			}
			
			persons[numPerson] = person(currPerson, parent, marriage);
			numPerson++;
		}//end of person command
		else
		{
			if (cmd == "Family")
			{
				vector<int> children;

				for(size_t i = 7; i < tokens.size(); i+=2)//last edit here
				{
					int j = stoi(tokens[i]);
					children.push_back(j);
				}

				int fam = stoi(tokens[1]);
				int husband = stoi(tokens[3]);
				int wife = stoi(tokens[5]);

				familia[numFam] = family(fam, husband, wife, children);
				numFam ++;
			}//end of family command
			else
			{
				if (cmd == "Relate")
				{
					int person1 = stoi(tokens[1]);
					int person2 = stoi(tokens[2]);

					relate(person1, person2, familia, numFam, persons, numPerson);
				}
				else
				{
					verify(familia, numFam, persons, numPerson);
				}//end of relate command
			}
		}
	}
return 0;
}//end of main
