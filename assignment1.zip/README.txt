Author: Monynich Kiem
Section: 002

I wasn't able to figure out how to pipe the perl script in with my program and use the seed part, since I was programming in c++ i was most comfortable with using th earugment variables in order for my program to read the perl script. I turned this project in late due to my inability to make the weight change every time I removed or added a card to a players stack until I recieved some advice from my friends and ended up re-writing my program using a class with my struct. I'm more comofrtable with OOP code and I elected to write more functions instead of my original three which were to add and remove cards from the bottom and top. Incorporating the weight functions with my other functions fixed my weight problem and I was finally able to move on with the assignment.

I compiled the program using g++ cards -o cards
I ran the program using ./cards randGen.pl _ _ _ 

I made a driver.cpp on top of my main cpp to save myself headache of deleting and rewriting too mucgh on the same file


