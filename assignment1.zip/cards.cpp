//Date: 1/26/2020
//Author: Monynich Kiem
//Section: 002
//Purpose: The purpose of cards is to have 3 input arguments for the number of players, the numbers of cards per player, 
//and the number of max turns before the game ends. 
//The game incorporates the weight of the cards that the players have and the game will end when the turns 
//are at the max or when one of the players' weight of cards 
//is equal to zero meaning there are no more cards in there hand. This program is made using circular arrays

#include <stdio.h>
#include <iostream>
#include <fstream>
#include "cards.h"
#include <stdlib.h>
#include <string>
using namespace std;

//call all the functions from header here

int main(int argc, char* argv[])
{
	// Check whether the number of command line arguments is exactly 3 
    	if (argc != 5)
    	{
        	cout << "Warning: need exactly three command line argument." << endl;
        	cout << "Usage: " << argv[0] << " inputfile_name" << endl;
        	return 1;
    	}

	if ((atoi(argv[2]) <= 0) || (atoi(argv[3]) <= 0) || (atoi(argv[4]) <= 0))
	{
		cout << "Please enter valid integers." << endl;
		return 2;
	}

	ifstream file;
	file.open(argv[1]);
	//this will open adn read randGen.pl
		
	int players = atoi(argv[2]);
	int numCards = atoi(argv[3]);
	int turns = atoi(argv[4]);

	file.close();

	int currTurn = 1;
	
	deque playersHands[players];
	for (int p = 0; p < players; p += 1)
	{
		for (int c = 0; c< numCards; c += 1)
		{
			playersHands[p].addCard(c);
		}
	}
	
	string answer;
	int topOrBottomCard = 0;
	int currWeight = 0;//this will later return 
	int findWeight = 0;//this is a player's weight which will be later used with the getWeight() function
	int compare = 0;//this will be used to compare weights in order to find the winner
	int tempWeight = playersHands[0].getWeight();

			for (currTurn = 1; currTurn < turns + 1; currTurn += 1)
			{
					int dualSidedDie = rand()%2+1;
                                        int advSidedDie = rand()%players+1;
                                        int disSidedDie = rand()%players+1;

					cout << "Turn " << currTurn << ":";
					cout << "Player " << advSidedDie << " sends a card to player " << disSidedDie << ", from " << answer <<endl;
					
					if (dualSidedDie == 1)
                			{	
                        			answer = "top";	
                				topOrBottomCard = playersHands[advSidedDie-1].getFront();
						playersHands[advSidedDie-1].removeTopCard();
						playersHands[disSidedDie-1].addCard(topOrBottomCard);
					}
                			if (dualSidedDie == 2)
                			{
						answer = "bottom";
						topOrBottomCard = playersHands[advSidedDie-1].getRear();
						playersHands[advSidedDie-1].removeBottomCard();
						playersHands[disSidedDie-1].addCard(topOrBottomCard);
                			}//these two if statements will get the value of the card of the top/bottom, remove the top/bottom card, then populate the losing card with the card that was previously removed from the player with advantages stack

					for (int k = 0; k < players; k += 1)
					{	
						cout << "        Player" << k+1 << ": Weight: " << playersHands[k].getWeight() << endl;						
					}
					for (int l = 0; l < players; l += 1)
					{
						currWeight = playersHands[l].getWeight();

						if (currWeight <= 0)
						{
							cout << "Game is over! Player " << l+1 << " has no cards left!" << endl;
							return 0;
						}
					}
			}

		cout << "Game is over. Out of turns." << endl;
		for (int m = 0; m < players; m+=1)
		{
			compare = playersHands[m].getWeight();
			if (tempWeight > compare)
			{
				tempWeight = compare;
			}
		}
		for (int n = 0; n < players; n +=1)
		{
			findWeight = playersHands[n].getWeight();
			if (findWeight == tempWeight)
			{
				cout << "Player " << n+1 << " has the smallest weight!" << endl;
			}
		}
	return 0;
}//end of main
