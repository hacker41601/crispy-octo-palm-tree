//Author: Monynich Kiem
//Section: 002;
//Purpose: This header file contains the necessary functions that will bbe implemented in the main cpp file knowns as cards.cpp
//~~~~~~~~~~~~~~~~~~
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
using namespace std;

struct Deck
{
        int data;
        Deck *next;
	Deck *prev;
	static Deck* getValue(int data)
	{
		Deck* newDeck = (Deck*)malloc(sizeof(Deck));
		newDeck->data = data;
		newDeck->prev = newDeck->next = NULL;
		return newDeck;
	}//the static function allows the struct to add new cards because it uses malloc which allocates memory and is called later in the add card function in order to create a new "node"
};//struct Dewck

class deque
{
	Deck* front;
	Deck* rear;
	int size;
	int playerWeight;
	public:
	deque()
	{
		front = NULL;
		rear = NULL;
		size = 0;
		playerWeight = 0;
	}
	void addCard(int data);
	void removeTopCard();
	void removeBottomCard();
	int getFront();
	int getRear();
	int getWeight();
	void dispCards();
};//class deque

void deque::addCard(int data)
{
	Deck* newDeck = Deck::getValue(data);
	if (newDeck == NULL)
	{
		cout << "Error: Overflow" << endl;
	}
	else
	{
		if (front == NULL)
		{
			rear = front = newDeck;
		}
		else
		{
			newDeck->next = front;
			front->prev = newDeck;
			front = newDeck;
		}
	size += 1;
	playerWeight = playerWeight + (getFront() * getFront());
	}
}//addCard(int data) creates a new Deck* object that calls the getValue function and populates it with the card values, creates a node space for the new card and populates it while increasing the deck size and recalculating the player's weight

void deque::removeTopCard()
{
	if (front == NULL)
	{
		cout << "Error: Underflow" << endl;
	}
	else
	{
		Deck* curr = front;
		playerWeight = playerWeight - (getFront() * getFront());
		front = front->next;
		if (front == NULL)
		{
			rear = NULL;
		}
		else
		{
			front->prev = NULL;
		}
	free(curr);
	size -= 1;
	}
}//removeTopCard() calculates the player's weight after remove a card on the top of the stack and then decreases the stack size

void deque::removeBottomCard()
{
	if (front == NULL)
	{
		cout << "Error: Underflow" << endl;
	}
	else
	{
		Deck* curr = rear;
		playerWeight = playerWeight - (getFront() * getFront());
		rear = rear->prev;
		if (rear == NULL)
		{
			front = NULL;
		}
		else
		{
			rear->next = NULL;
		}
	free(curr);
	size -= 1;	
	}
}//removeBottomCard() calculates the player's weight after remove a card on the bottom of the stack and then decreases the deck size - the same as removeTopCard() but starting at the first if statement it is the opposite

int deque::getFront()
{
	if (front == NULL)
	{
		return -1;
	}
	return front->data;
}//getFront() return the first card in the pile

int deque::getRear()
{
	if (front == NULL)
	{
		return -1;
	}
	return rear->data;
}//getRear() return the last card in the pile

int deque::getWeight()
{
	return playerWeight;
}//getWeight() returns the player's current weight 
