//Author: Monynich Kiem
//Date: 03/19/2020
//Last Mod: 03/23/2020
//Purpose: A program called kd that (1) takes a parameter n, which should be a positive integer, indicating how many data points are to be placed in the tree, and a parameter p, indicating the number of probes into the tree; (2) reads from standard input a list of n 4-dimensional integer data points; (3) builds a k-d tree with those n values using the offline method, with b set to 10 (and ties going to the left subtree); (4) reads p 4-dimensional data values, called probes, and for each probe, lists all the data points stored in the bucket where the probe would be found if it were in the tree.

#include<stdlib.h>
#include<stdio.h>
#include<iostream>
using namespace std;

const int k = 4; //this is to represent the number of dimensions in this kd tree

struct point
{
        int  x,y,z,t;
	int data;
}; //end of point struct

struct Node
{
	int point[k];
	Node *left;
	Node *right;
}; //end of Node struct

struct Node *newNode(int arr[])
{
	struct Node *temp = new Node;
	for (int i = 0; i < k; i+=1)
		temp->point[i] = arr[i];
	temp->left = temp->right = NULL;
	return temp;
} //end of newNode function: this is will create a node/leaf/bucket for the kd tree

int partition(int arr[], int l, int r)
{
    int x = arr[r];
    int i = l;

    for (int j = l; j <= r - 1; j+=1)
    {
        if (arr[j] <= x)
        {
            swap(arr[i], arr[j]);
            i+=1;
        }
    }
    swap(arr[i], arr[r]);
    return i;
} //this is the partition algorithm referenced from Dr.Finkel's notes

Node *insertNode(Node *root, int point[], unsigned depth)
{
	if(root==NULL)
		return newNode(point);
	unsigned currDim = depth%k;
	if (point[currDim] < (root->point[currDim]))
		root->left = insertNode(root->left, point, depth+1);
	else
		root->right = insertNode(root->right, point, depth+1);
	return root;
} //end of insertNode function that will place the nodes on the trees with ties going to the left subtree

Node *insertPoint(Node* root, int point[])
{
	return insertNode(root, point, 0);
} //end of insertPoint function that uses the insertNode function recursively 

bool arePointsEqual(int point1[], int point2[])
{
	for (int i = 0; i < k; i+=1)
		if (point1[i] != point2[i])
			return false;
	return true;
} //end of arePointsEqual function : a boolean function that will determine if the points I'm searching for are equal to one another

bool searchNode(Node* root, int point[], unsigned depth)
{
	if (root == NULL)
		return false;
	if (arePointsEqual(root->point, point))
		return true;

	unsigned currDim = depth%k;

	if(point[currDim] < root->point[currDim])
		return searchNode(root->left, point, depth+1);
	return searchNode(root->right, point, depth+1);
} //end of searchNode function that traverses the kd tree in search of the points given

bool searchPoint(Node* root, int point[])
{
	return searchNode(root, point, 0);
} //this uses the searchNode function recursively

int main (int argc, char *argv[])
{
	if (argc != 3)
	{
		cout << "Warning: Need 2 Command Line Arguments\n"; 
		return 0;
	} //end of if statement that fails gently if the argument requirements aren't met
	
	int n, p; //n = numPoints, p = numProbes
	n = atoi(argv[1]);
	p = atoi(argv[2]);
	struct Node *root = NULL; //initialize the root to be empty before starting
	point value;

	int points[n][k]; //points is a 2d array with the dimensions of n by k
	point buckets[n][k]; //buckets is a point variable 2d array with the dimensions of n by k as well

	cin >> value.x >> value.y >> value.z >> value.t; //this initializes the 4 dimensions of the data points from standard input
	
	for (int a = 0; a < p; a+=1) 
	{
		for (int c = 0; c < k; c+=1) 
		{
			cin >> value.x >> value.y >> value.z >> value.t;
			scanf("%d", &points[a][c]);
			int size = sizeof(points)/sizeof(points[0]); 
			for (int i = 0; i < size; i++)
				root = insertPoint(root, points[i]); 
		} // end of for loop that initializes, populates, and inserts the data into the tree
		for (int b = 1; b < p; b+=1) 
		{
			cout << "The Probe: " << value.x << " " << value.y << " " << value.z << " " << value.t << " reaches bucket: " << "10 elements" << endl;	
			for (int d = 0; d < n; d+=1) 
			{
				scanf("%d %d %d %d", &buckets[a][d].x, &buckets[a][d].y, &buckets[a][d].z, &buckets[a][d].t );
				printf("%d, %d, %d, %d", buckets[a][d].x, buckets[a][d].y, buckets[a][d].z, buckets[a][d].t);
				cout << endl;
			} // end of for loop that scans prints out the contents of the bucket that the probe would be held in
		} //end of for loop that prints out the probe values
	} // end of outtermost for loop that iterates the variable a up to the value of n;
	
	return 0;
} //end of main function
