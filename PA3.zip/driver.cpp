//This is my cpp file to test out my functions. The purpose of the search functions is to see whether or not the points I plotted were plotted correctly and could be found. Due to my preference of structs and limited knowledge of vectors, I opted for a more traditional tree using 2d arrays. The comments on these functions will be found on the kd.cpp program itself.

//Author: Monynich Kiem
//File: driver.cpp
//Purpose: Test functions

#include<stdlib.h>
#include<stdio.h>
#include<iostream>
using namespace std;

const int k = 4;

struct point
{
        int  x,y,z,t;
        int data;
};

struct Node
{
        int point[k];
        Node *left;
        Node *right;
};

struct Node *newNode(int arr[])
{
        struct Node *temp = new Node;
        for (int i = 0; i < k; i+=1)
                temp->point[i] = arr[i];
        temp->left = temp->right = NULL;
        return temp;
}

int partition(int arr[], int l, int r)
{
    int x = arr[r];
    int i = l;

    for (int j = l; j <= r - 1; j+=1)
    {
        if (arr[j] <= x)
        {
            swap(arr[i], arr[j]);
            i+=1;
        }
    }
    swap(arr[i], arr[r]);
    return i;
}

Node *insertNode(Node *root, int point[], unsigned depth)
{
        if(root==NULL)
                return newNode(point);
        unsigned currDim = depth%k;
        if (point[currDim] < (root->point[currDim]))
                root->left = insertNode(root->left, point, depth+1);
        else
                root->right = insertNode(root->right, point, depth+1);
        return root;
}

Node *insertPoint(Node* root, int point[])
{
        return insertNode(root, point, 0);
}

bool arePointsEqual(int point1[], int point2[])
{
        for (int i = 0; i < k; i+=1)
                if (point1[i] != point2[i])
                        return false;
        return true;
}

bool searchNode(Node* root, int point[], unsigned depth)
{
        if (root == NULL)
                return false;
        if (arePointsEqual(root->point, point))
                return true;

        unsigned currDim = depth%k;

        if(point[currDim] < root->point[currDim])
                return searchNode(root->left, point, depth+1);
        return searchNode(root->right, point, depth+1);
}

bool searchPoint(Node* root, int point[])
{
        return searchNode(root, point, 0);
}

int main()//driver
{
        struct Node *root = NULL;
        int points[][k] = {{3, 6, 8, 10}, {17, 15, 18, 20}, {13, 15, 17, 18}, {6, 12, 13, 14},
                                {9, 1, 2, 3}, {2, 7, 8, 9}, {10, 19, 20, 21}};
        int n = sizeof(points)/sizeof(points[0]);

        for (int i=0; i<n; i++)
                root = insertPoint(root, points[i]);

        int point1[] = {10, 19, 20, 21};
        (searchPoint(root, point1))? cout << "Found\n": cout << "Not Found\n";

        int point2[] = {12, 19, 3, 4};
        (searchPoint(root, point2))? cout << "Found\n": cout << "Not Found\n";

    return 0;
}
