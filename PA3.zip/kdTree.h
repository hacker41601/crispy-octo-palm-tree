//Author: Monynich Kiem
//Date: 03/19/2020
//Purpose: This is a header file I was initally going to use in my final progrm but ended up scrapping because it had a lot of helper functions that I wasn't sure made sense nor could I find where they'd be implemented in the current way I build my kd tree now

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

const int k = 4;
//k is the number of dimensions
const int b = 10;
//b is the max number of buckets allowed at the end of leaves

struct Node
{
	int point[k];
	Node *left, *right;
};

struct Node *newNode(int arr[])
{
	struct Node* temp = new Node;

	for (int i = 0; i < k; i+=1)
	{
		temp->point[i] = arr[i];
	}

	temp->left = temp->right = NULL;
	return temp;
};

Node *insertNode(Node *root, int point[], unsigned depth)
{
	if (root == NULL)
	{
		return newNode(point);
	}

	unsigned currD = depth % k;

	if (point[currD] < (root->point[currD]))
	{
		root->left = insertNode(root->left, point, depth+1);
	}
	else
	{
		root->right = insertNode(root->right, point, depth+1);
	}
	return root;
}

Node *insertPoint(Node *root, int point[])
{
	return insertNode(root, point, 0);
}

void searchTree(Node* root, int point[], unsigned depth)
{
	unsigned currD = depth % k;
	if (point[currD] < root->point[currD])
	{
		return searchTree(root->left, point, depth+1);
	}
	return searchTree(root->right, point, depth +1);
}

void search(Node *root, int point[])
{
	return searchTree(root, point, 0);
}

int getMin(int point[], int n)
{
	int res = point[0];

	for (int i = 1; i < n; i+=1)
	{
		res = min(res, point[i]);
	}
	return res;
}

int getMax(int point[], int n)
{
	int res = point[0];

	for (int i = 1; i < n; i+=1)
	{
		res = max(res, point[i]);
	}
	return res;
}

void findRange(int point[], int n)
{
	int max = getMax(point, n);
	int min = getMin(point, n);
	int range = max - min;
}

int findMedian(int point[], int n)
{
	selectionSort(point, n);

	if(n%2 != 0)
	{
		return point[n/2];
	}
	return (point[(n-1)/2] + point[n/2])/2;
} 
