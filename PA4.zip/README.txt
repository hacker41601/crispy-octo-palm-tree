README FILE
Author: Monynich Kiem
References:Dr. Finkel's notes and specific websites will be listed below
Date: 04/08/2020
Course: CS315-002

For this project, I had a difficult time understanding how to convert a vector object into an array in order to sort the elements within the array. However, in order to test if my hash tables were correctly I went ahead and implemented the sort() function found in algorithm in order to see if my code worked for the most part and then in the end work on how to sort it last.

I made 2 structs in order to compare words with one another in the compare struct and then the other struct was to access the lines and the words for their count and string. The rest of the functions were to take in my input from standard input, compare words, and count them as they were compared for distinctness. I made sure to list the words in descending order and was unable to figure out how to do it alphabetically. 

I had issues with my string input and used getline instead of cin because it seemed to make more sense to read by the line and compare rather than just a single word at a time where it would take longer. 

These are the websites I used other than the CS315 website for my understanding of this project and implementation of my code. 
I have comments in my code expressing where I used references as well.

http://www.cplusplus.com/reference/vector/vector/

http://www.cplusplus.com/reference/sstream/istringstream/str/

https://www.sanfoundry.com/cpp-program-find-number-words-given-sentence/ (I used this mainly to understand how I would implement a counting function in the main file)

http://www.cplusplus.com/reference/algorithm/sort/

https://www.geeksforgeeks.org/internal-details-of-stdsort-in-c/ (this is to help me understand how I could implement my own algorithm when hardcoding rather than using a given function by the algorithm routine)

https://www.geeksforgeeks.org/hashing-set-1-introduction/ (this just gave me a simplified idea of what hashing means)

https://www.includehelp.com/cpp-programs/sort-names-in-an-alphabetical-order.aspx (this website showed me how to hardcode the strcmp() function instead b/c I didn't quite understand how to implement it using the function itself.)

For further clarification on my attempts to convert ny vector into an array here are my snippets of code:

int array[size];
        int arrayIndex = 0;
        for (auto i = words.begin(); i != words.end(); i+=1)
        {
                //array[arrayIndex] = *i.data();
                arrayIndex++;
        }

        wordCounter arr[size];
        copy(words.begin(), words.end(), arr);
