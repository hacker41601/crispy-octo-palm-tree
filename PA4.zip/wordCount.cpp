//Author: Monynich Kiem
//Date: 04/08/2020
//Class: CS315 - 02
//Purpose: Your program, called "wordCount", should accept the text file from standard input. It should generate both lists to standard output, with a single blank line between the lists, and no other information (such as headings). There should be a single space between the word and its count on each line.
//You must use a hash table to store the counts. You may use any hash function you wish, but you must use external chaining.
//You must write your own sorting algorithm to sort the output. You will lose 2 points if you use selection sort or insertion sort; you will get full credit for shell sort, heap sort, quicksort, or merge sort. You must not use any other sorting method.
//You may write the program in C, C++, or Java. You may not use any library routines for hashing or for sorting, but you may use strncmp() (in C or C++), or the string method compare() (in C++) or compareTo() (in Java). You may use the Vector classes available in C++ and Java.

#include <stdlib.h>
#include <stdio.h>
#include <fstream> //for opening and closing files
#include <vector>
#include <iostream>
#include <string>
#include <iomanip> //to set the width and make the display neater
#include <sstream>
#include <algorithm> //to use copy()
using namespace std;

struct wordCounter
{
	string words;
	int count;

	void counter()
	{
		count ++;
	}

	wordCounter(string w)
	{
		words = w;
		count = 1; //count should start at one since it will only display words that appear at all
	}
}; //end of wordCounter struct in which it is initialized with an associated string and integer for the hash table to be organized later on

struct
{
	bool operator() (const wordCounter& x, const wordCounter& y)
	{
		if (x.count < y.count)
			return false;
		else if (x.count > y.count)
			return true;
		else
		{
			if (x.words < y.words)
				return true;
			else
				return false;
		}
	}
} compare; //end of compare struct that determins how the numbers and their corresponding words will be displayed later on in descending order

int partition(vector<int>&array, int begin, int end)
{
        int x = array[begin];
        int i = begin -1;
        int j = end +1;
        int temp;

        do {
                do {
                        j --;
                }while (x>array[j]);

                do {
                        i ++;
                } while (x < array[i]);

                                if (i < j)
                                {
                                        temp = array[i];
                                        array[i] = array[j];
                                        array[j] = temp;
                                }
                        }while (i < j);
        return j;
}

void quickSort(vector<int> &num, int begin, int end)
{
        int middle;
            if (begin < end)
            {
                    middle = partition(num, begin, end);
                    quickSort(num, begin, middle);
                    quickSort(num, middle+1, end);
            }
return;
}

string inputWords();
vector<wordCounter> uniqueWords(string);
bool search(string, vector<wordCounter>&);
void display(vector<wordCounter>);
bool myComp(string x, string y);
int partition(vector<int>&array, int begin, int end);
void quickSort(vector<int> &num, int begin, int end);

int main()
{
	string current = inputWords();
	while (current != "")
	{
		vector<wordCounter> words = uniqueWords(current); //the vector is populated with distinct words from the current input
		cout << "There are " << words.size() << " unique words from data.txt\n";
		cout << "----------\n";	
		display(words); 
		current = inputWords(); //the current is continued to update so long as it isn't ""
		current = "";
	}

return 0;
} //end of main

string inputWords()
{
	ifstream input;
	string tempStr;
	string textStr;

	input.open("data.txt");
	if (!input)
	{
		cout << "Error Reading data.txt\n";
	}
	else
	{
		while (!input.eof())
		{
			getline(input, tempStr);
			textStr+=tempStr;
		}
	}
	input.close();
	return textStr;
} //end of inputWords in which the function opens up the data.txt file and takes the words in from standard input so that the main is much shorter and mostly calls functions

vector<wordCounter> uniqueWords(string str)
{
	vector<wordCounter> words;
	string tempStr;
	istringstream iss(str); //I looked up why my while loop wasn't working and used iss() in order to copy/ move over my string and implement it instead for my tempStr
	while(iss >> tempStr)
	{
		if(search(tempStr, words) == true) 
		{
			continue; //it will continue to go through the words and take on a new tempStr
		}
		else
		{
			wordCounter tempObject(tempStr);
			words.push_back(tempObject); //adds the object is the search if false and it hasn't shown up yet
		}
	}
return words;	
} //end of uniqueWords function in which is traverses and compares the current or temporary string to the words given and adds them if they haven't appeared yet

bool search(string str, vector<wordCounter>& words)
{
	for (auto& a:words)
	{
		if(a.words.compare(str) == 0)
		{
			a.counter();
			return true;
		}
	}
}//end of search function that traverses through the words given and counts its appearances

struct
{
	bool operator() (const wordCounter& x, const wordCounter& y)
	{
		if (x.words < y.words)
			return true;
	} //similar to strcmp operation
} alphabetical;//end of myComp function that acts as a strcmp operation

//checking to see if it actually does anything
void display(vector<wordCounter> words)
{
	//put the sorting algorithm here!
	//set the width to 34 for an adequately long unique word
	cout << "In descending number of appearances:\n\n";
	cout << "Words" << setw(34) << "Count\n";
	cout << "--------------------\n";
	
	//implement sorting algorithm
	sort(words.begin(), words.end(), compare);

	for (auto& b : words)
	{
		cout << setw(20) << left << b.words;
		cout << setw(15) << right << b.count << endl; 
	}
	
	cout << "\nIn alphabetical order:\n\n";
	cout << "Words" << setw(34) << "Count\n";
        cout << "--------------------\n";
	sort(words.begin(), words.end(), alphabetical);

	for (auto& c : words)
	{
		cout << setw(20) << left << c.words;
		cout << setw(15) << right << c.count << endl;
	}

	// vector<int> numApp;
	//quickSort(numApp, numApp[0], numApp[wordAppearance]);

} //end of display function to display the unique words and it's number of appearances


